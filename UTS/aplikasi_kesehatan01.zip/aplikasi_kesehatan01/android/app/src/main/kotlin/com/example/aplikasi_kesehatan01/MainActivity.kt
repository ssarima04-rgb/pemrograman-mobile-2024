package com.example.aplikasi_kesehatan01

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
