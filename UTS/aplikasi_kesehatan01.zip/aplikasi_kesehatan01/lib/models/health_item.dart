/// Model class to store health article data
/// This class represents each health item shown in the list
class HealthItem {
  final String id;
  final String title;
  final String shortDescription;
  final String fullDescription;
  final String imagePath;
  final String category;

  HealthItem({
    required this.id,
    required this.title,
    required this.shortDescription,
    required this.fullDescription,
    required this.imagePath,
    required this.category,
  });
}

/// Sample data - 5 health-related items
/// In a real app, this might come from an API or database
List<HealthItem> sampleHealthData = [
  HealthItem(
    id: '1',
    title: 'Manfaat Olahraga Pagi',
    shortDescription: 'Mulai hari dengan energi positif dan tubuh sehat.',
    fullDescription: 'Olahraga pagi memiliki banyak manfaat bagi kesehatan fisik dan mental. Dari meningkatkan metabolisme, memperbaiki kualitas tidur, hingga mengurangi stres. Lakukan minimal 15-30 menit setiap pagi untuk hasil optimal.',
    imagePath: 'assets/images/olahraga_rutin.jpg',
    category: 'Olahraga',
  ),
  HealthItem(
    id: '2',
    title: 'Pola Makan Seimbang',
    shortDescription: 'Kunci hidup sehat dengan nutrisi yang tepat.',
    fullDescription: 'Pola makan seimbang terdiri dari karbohidrat, protein, lemak sehat, vitamin, dan mineral. Konsumsi beragam makanan seperti sayuran, buah-buahan, biji-bijian, dan protein tanpa lemak untuk memenuhi kebutuhan gizi harian.',
    imagePath: 'assets/images/pola_makan.jpg',
    category: 'Nutrisi',
  ),
  HealthItem(
    id: '3',
    title: 'Tips Tidur Berkualitas',
    shortDescription: 'Istirahat cukup untuk regenerasi sel tubuh.',
    fullDescription: 'Tidur berkualitas selama 7-9 jam per malam penting untuk kesehatan. Matikan gadget 1 jam sebelum tidur, ciptakan lingkungan tidur yang nyaman, dan pertahankan jadwal tidur yang konsisten.',
    imagePath: 'assets/images/tidur.jpg',
    category: 'Istirahat',
  ),
  HealthItem(
    id: '4',
    title: 'Minum Air Putih',
    shortDescription: 'Hidrasi optimal untuk fungsi tubuh maksimal.',
    fullDescription: 'Minum 8 gelas air per hari membantu menjaga suhu tubuh, melumasi sendi, melindungi sumsum tulang belakang, dan membuang limbah melalui urin, keringat, dan buang air besar.',
    imagePath: 'assets/images/kesehatan.jpg',
    category: 'Hidrasi',
  ),
  HealthItem(
    id: '5',
    title: 'Meditasi & Relaksasi',
    shortDescription: 'Tenangkan pikiran untuk kesehatan mental.',
    fullDescription: 'Meditasi rutin dapat mengurangi stres, kecemasan, dan depresi. Mulai dengan 5-10 menit per hari, fokus pada pernapasan, dan tingkatkan durasi secara bertahap untuk manfaat maksimal.',
    imagePath: 'assets/images/hidup_sehat.jpg',
    category: 'Mental',
  ),
];